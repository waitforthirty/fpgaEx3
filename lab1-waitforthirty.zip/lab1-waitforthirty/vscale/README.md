<img src="http://albert-magyar.github.io/vscale/vscale.svg">

# vscale

In order to build and test vscale using the supplied makefile,
Synopsys VCS must be installed and on the path.

```
git clone git@github.com:ucb-bar/vscale.git
cd vscale
make
make run-asm-tests
```

